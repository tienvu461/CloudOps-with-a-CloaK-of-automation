# std lib
import datetime
import json
import os
import logging
import requests

ENV = os.getenv("ENV", "dev")
PROJECT = os.getenv("PROJECT", "")
# logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
logger.setLevel(level=logging.DEBUG)

# Const
WEBHOOK_URL = os.getenv("WEBHOOK_DISCORD", "https://discord.com/api/webhooks/1163106007598256228/H-NQ1v08Y1cfdsv2mDAPmoaWjzzKD9MsmVyZUXns5_uXHxPvtW4rx2JXEbXnHWXR6Elp")


def create_payload(event):
  subject = event["Subject"]
  message = json.loads(event["Message"])
  alarm_name = message["AlarmName"]
  alarm_desc = message["AlarmDescription"]
  env = message["AlarmName"].split("-")[1]
  component = message["AlarmName"].split("-")[2]
  
  description = """
+ Alarm Name  : **{}**
+ Description : {}
+ Environment : **{}**
+ Component   : **{}**
+ URL         : https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#alarmsV2:alarm/{}
""".format(alarm_name.upper(), alarm_desc, env.upper(), component.upper(), alarm_name)

  return {
        'embeds': [
            {
                'title': 'AWS Cloudwatch: ' + subject,
                'description': description,
                'color': 0xFF0000,
                'timestamp': event["Timestamp"],
            }
        ]
    }

def lambda_handler(event, _context):
    logger.info("event: {}".format(json.dumps(event)))
    message = create_payload(event["Records"][0]["Sns"])
    requests.post(
       WEBHOOK_URL, 
       data=json.dumps(message),
       headers={
          'Content-Type': 'application/json',
        },
    )

    return True
